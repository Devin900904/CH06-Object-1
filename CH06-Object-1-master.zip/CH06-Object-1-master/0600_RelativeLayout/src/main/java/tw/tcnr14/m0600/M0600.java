package tw.tcnr14.m0600;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class M0600 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m0600);
    }
}